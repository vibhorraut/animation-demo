import React, { useState } from 'react';
import { CSSTransition } from 'react-transition-group';
import './AnimatedComponent.css';

const AnimatedComponent = () => {
  const [inProp, setInProp] = useState(false);

  return (
    <div>
      <CSSTransition in={inProp} timeout={200} classNames="my-node">
        <div className="box">Hello, I am an animated box!</div>
      </CSSTransition>
      <button onClick={() => setInProp(!inProp)}>
        Click to Enter
      </button>
    </div>
  );
}

export default AnimatedComponent;