import React, { useState } from 'react';
import { CSSTransition } from 'react-transition-group';
import './SlideComponent.css';

const SlideComponent = () => {
  const [inProp, setInProp] = useState(false);

  return (
    <div>
      <CSSTransition in={inProp} timeout={300} classNames="slide">
        <div className="slide-box">Slide me in and out!</div>
      </CSSTransition>
      <button onClick={() => setInProp(!inProp)}>
        Toggle Slide
      </button>
    </div>
  );
}

export default SlideComponent;