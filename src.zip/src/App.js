import React from 'react';
import './App.css';
import AnimatedComponent from './components/AnimatedComponent';
import SlideComponent from './components/SlideComponent';

const App = () => {
  return (
    <div className="App">
      <header className="App-header">
        <h1>React Animation Demo</h1>
        <AnimatedComponent />
        <SlideComponent />
      </header>
    </div>
  );
}

export default App;